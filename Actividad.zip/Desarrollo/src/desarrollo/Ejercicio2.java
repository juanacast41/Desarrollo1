/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desarrollo;

import java.util.Scanner;

/**
 *
 * @author Juana
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("");
        System.out.println("NOTAS DE ALUMNOS");
        
        Scanner entrada = new Scanner (System.in);
        
        String nombre;
        double evaluacion1;
        double evaluacion2;
        double evaluacion3;
        double evaluacionfinal;
        
        System.out.println("Nombre del alumno: ");
        nombre=entrada.nextLine();
        System.out.println("");
        System.out.println("Nota de la primera evaluacion: ");
        evaluacion1= entrada.nextDouble();
        System.out.println("");
        System.out.println("Nota de la segunda evaluacion: ");
        evaluacion2= entrada.nextDouble();
        System.out.println("");
        System.out.println("Nota de la tercera evaluacion: ");
        evaluacion3= entrada.nextDouble();
        System.out.println("");
        evaluacionfinal=(evaluacion1 + evaluacion2 + evaluacion3)/3;
        System.out.println("La media de las notas es: " +evaluacionfinal);
        
        
        
        
        
    }
    
}
