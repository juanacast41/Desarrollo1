/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package desarrollo;

/**
 *
 * @author Juana
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("");
        System.out.println("DECLARACION DE OPERACIONES");
        
        int a=10;
        int b=5;
        
        int suma= a+b;
        int resta=a-b;
        int mul=a-b;
        int div=a/b;
        
        System.out.println("La suma de " +a+ " mas" +b+ " es igual a: " +suma);
        System.out.println("La resta de " +a+ " menos" +b+ " es igual a: " +resta);
        System.out.println("La multiplicacion de " +a+ " multiplicado" +b+ " es igual a: " +mul);
        System.out.println("La division de " +a+ " dividido" +b+ " es igual a: " +div);
    }
    
}
